const toggleBtn = document.querySelector(".toggle_btn")
const toggleBtnIcon = document.querySelector(".toggle_btn i")
const dropDownMenu = document.querySelector(".dropdown_menu")

toggleBtn.onclick = function () {
  dropDownMenu.classList.toggle("open")
  const isOpen = dropDownMenu.classList.contains("open")

  toggleBtnIcon.classList = isOpen 
    ? "fa-solid fa-xmark" : 
  "fa-solid fa-bars";
}

// typing script 
const typed = new Typed('#typed', {
  strings: ['UI Developer','React Developer','Angular Developer'],
  typeSpeed:60,
  backSpeed: 50,
  loop: true
});
// typing script 

